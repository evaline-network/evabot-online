# EvaBot & Evaline Online — Full Enterprise Project Documentation

> **System Version:** v2.7.0 / Release v0.0.1  
> **Infrastructure:** Google Cloud Platform (Frankfurt `c3-standard-8` & Iowa `e2-micro`)  
> **Production Domain:** [https://evabot.online](https://evabot.online)  
> **GitHub Repository:** [`evabot-online/evaline-online`](https://github.com/evabot-online/evaline-online)  

---

## 1. Executive Summary & Architecture Overview

**EvaBot & Evaline Online** is a modular enterprise AI ecosystem and autonomous control center running on Google Cloud Platform (GCP). The architecture strictly separates high-volume public web ingress from core AI computation workloads.

```mermaid
flowchart TD
    User([Public Web & API Users]) -->|HTTPS / TLS 1.3 / HTTP/3| Caddy[Caddy Web Server 2.11.4]
    
    subgraph Edge_Node ["Edge Node: evaline-micro-vm (Iowa, us-central1-a) — Always Free ($0.00/mo)"]
        Caddy --> WebRoot["/var/www/evabot.online (Static Glassmorphic UI)"]
        Caddy --> ReverseProxy[Reverse Proxy / Edge Shield]
    end

    ReverseProxy -->|Tailscale WireGuard Mesh 100.125.200.49| AgentVM
    
    subgraph Core_Node ["Primary Compute Node: evabot-agent-vm (Frankfurt, europe-west3-a)"]
        AgentVM[c3-standard-8: 8 vCPU Sapphire Rapids, 32GB RAM]
        AgentVM --> Qdrant[Qdrant Vector Database]
        AgentVM --> Messengers[Messenger Gateways: Telegram, WhatsApp, Viber, FB]
        AgentVM --> GeminiAPI[Google Gemini Core API / Google AI Pro]
    end
```

### Key Infrastructure Specifications

| Parameter | Edge Ingress Sentinel (`evaline-micro-vm`) | Core Compute Node (`evabot-agent-vm`) |
| :--- | :--- | :--- |
| **GCP Zone** | `us-central1-a` (Council Bluffs, Iowa, US) | `europe-west3-a` (Frankfurt, Germany) |
| **Machine Type** | `e2-micro` (2 vCPU burst, 1 GB RAM) | `c3-standard-8` (8 vCPU Sapphire Rapids, 32 GB RAM) |
| **Operating System** | Debian 13 (Trixie 13.6) | Debian 12 (Bookworm) |
| **Primary Role** | Ingress, TLS 1.3/HTTP3 Caddy, Static UI | Gemini AI Core, Qdrant Vector DB, Messenger Bots |
| **Public IP** | `136.114.26.252` | `34.179.253.183` |
| **Private Mesh IP**| `10.128.0.2` (VPC) / Tailscale Mesh | `10.156.0.2` (VPC) / Tailscale Mesh |
| **Monthly Cost** | **$0.00 / month** (€0.00 / month) | **~$290.00 – $320.00 / month** (€268.00 – €296.00 / month) |

---

## 2. Interactive Web Dashboard (7 Functional Screens)

The main web application (`index.html`) is structured into seven tabbed control screens:

1. **Screen 1: Gemini Conversational Core & Live Gemini Voice Assistant**
   - Real-time text interface powered by Google Gemini (Google AI Pro subscription with 2,000,000 token context window).
   - Live speech recognition and female text-to-speech engine with multi-language articulation.
2. **Screen 2: Physical & Virtual Cluster Telemetry**
   - Real-time CPU, RAM, disk NVMe throughput, network load, and system health metrics for both Frankfurt and Iowa nodes.
3. **Screen 3: Financial OpEx & Accounting Ledger**
   - Complete breakdown of GCP infrastructure costs strictly in **USD ($)** and **EUR (€)**.
   - Interactive transaction ledger, revenue/expense P&L summary, and financial category filters.
4. **Screen 4: AI Model Hub**
   - Catalog of Top-10 Smartest Frontier Models (Gemini 2.0 Pro, Claude 3.5 Sonnet, GPT-4o, DeepSeek-R1) and Top-10 Free/Open-Weights Models (Llama 3.3 70B, Mistral Small 3, Qwen 2.5 72B).
5. **Screen 5: Omnichannel Messenger Gateways**
   - Webhook & bot gateway connection status for Telegram, WhatsApp, Viber, and Facebook Messenger.
6. **Screen 6: Chronological Audit Log & Voice Narration**
   - Timestamped system audit stream recording deployment milestones, SSL renewals, and configuration updates.
7. **Screen 7: Interactive Kanban Board**
   - Agile project management board with 4 workflow columns: **Backlog**, **In Progress**, **Review**, and **Done**.
   - Dynamic task creation, status badges (`HIGH`, `MED`, `LOW`), tag filters (`#GCP`, `#AI`, `#DevOps`), and card movement.

---

## 3. Standalone CLI Client (`evabot-cli.py`)

The terminal CLI client provides lightweight ASCII management directly on Linux environments with zero external dependencies.

### Command Usage Options

```bash
# Interactive terminal dashboard
python3 evabot-cli.py

# Run non-interactive automated self-test
python3 evabot-cli.py --test

# Show CLI help and options
python3 evabot-cli.py --help
```

---

## 4. Automated Three-Way Git & GCP Synchronization

Synchronization between the local development environment, GitHub, and the live GCP microserver is managed via [`deploy-sync.sh`](file:///home/fedor/Desktop/evabot-online/deploy-sync.sh).

```
[Local Desktop: /home/fedor/Desktop/evabot-online]
       │
       ▼ (git push)
[GitHub Repository: evabot-online/evaline-online (main)]
       │
       ▼ (gcloud ssh & git pull)
[GCP Microserver: /home/fedor/Desktop/evabot-online]
       │
       ▼ (sudo cp / rsync)
[Live Web Root: /var/www/evabot.online]
```

### Executing Synchronization

```bash
./deploy-sync.sh "feat: update documentation and screens"
```

---

## 5. OpEx Financial Model & Cost Optimization

| Cost Component | Monthly Cost (USD) | Monthly Cost (EUR) | Billing Policy |
| :--- | :--- | :--- | :--- |
| `evaline-micro-vm` (e2-micro) | **$0.00** | **€0.00** | GCP Always Free Tier (Iowa, 744 hours/mo) |
| Boot Storage (20 GB HDD) | **$0.00** | **€0.00** | GCP Always Free (up to 30 GB free) |
| Network Egress (< 1 GB) | **$0.00** | **€0.00** | GCP Always Free quota |
| `evabot-agent-vm` (c3-standard-8) | **~$290.00 – $320.00** | **~$268.00 – €296.00** | On-Demand compute tier (Frankfurt) |
| NVMe Data Disk (50 GB) | **~$5.00** | **~$4.60** | Zonal SSD storage |
| Google AI Pro Subscription | **$20.00** | **€18.50** | Monthly fixed rate (Gemini 2M Context) |
| **Total Monthly Infrastructure OpEx** | **~$315.00 – $345.00** | **~$291.00 – €319.00** | Strict USD/EUR billing |

> [!TIP]
> Using `evaline-micro-vm` as an edge proxy instead of a GCP Cloud Application Load Balancer saves **$28.50 – $35.00 / month (€26.40 – €32.40 / month)** in forwarding rule fees.
