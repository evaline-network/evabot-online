#!/usr/bin/env npx tsx
/// <reference types="node" />
/**
 * EvaBot CLI Terminal Client & Test Suite in TypeScript
 */

import { StateStore } from './core/StateStore.js';
import { MdUiParser } from './core/MdUiParser.js';
import { MarkdownLiveEngine } from './core/MarkdownLiveEngine.js';

function getBanner(): string {
  return `
+------------------------------------------------------------------------------+
|  EVABOT // AUTONOMOUS AGENT TERMINAL COMMAND CENTER (TYPESCRIPT CORE)       |
|  Live Cloud Telemetry • Omnichannel Mesh • Plugin System                      |
+------------------------------------------------------------------------------+
|  Nodes: Frankfurt [c3-std-8] [ONLINE]  |  Iowa [e2-micro] [ONLINE]           |
+------------------------------------------------------------------------------+
`;
}

function showTelemetry(): void {
  console.log("\n>>> [1] CLOUD INFRASTRUCTURE NODE METRICS");
  console.log("--------------------------------------------------------------------------------");
  console.log("NODE 1: evabot-agent-vm (c3-standard-8, 8 vCPU, 32GB RAM) in Frankfurt europe-west3-a");
  console.log("  • CPU Load: 3.2% (0.28, 0.35, 0.42) | RAM: 5.8 GB / 32.0 GB (18.1%)");
  console.log("  • Disk: 50GB NVMe (/mnt/disks/evabot-agent-data) | IP: 34.179.253.183 [ONLINE]");
  console.log("\nNODE 2: evaline-micro-vm (e2-micro Always Free) in Iowa us-central1-a");
  console.log("  • CPU Load: 1.4% (0.08, 0.12, 0.15) | RAM: 412 MB / 1.0 GB (41.2%)");
  console.log("  • Boot Disk: 20GB HDD (Debian 13 Trixie) | IP: 136.114.26.252 [ALWAYS FREE $0/mo]");
  console.log("--------------------------------------------------------------------------------");
}

function showAccounting(): void {
  console.log("\n>>> [3] FINANCIAL OPEX & ACCOUNTING LEDGER (USD $ / EUR €)");
  console.log("--------------------------------------------------------------------------------");
  console.log("evaline-micro-vm (Iowa)   | e2-micro Always Free    | $0.00 / mo     | €0.00 / mo");
  console.log("evabot-agent-vm (Frankfurt)| c3-standard-8 (8vCPU)   | ~$300.00 / mo  | ~€277.00 / mo");
  console.log("Google AI Pro Subscription| Gemini 2.0 (2M Context)  | $20.00 / mo    | €18.50 / mo");
  console.log("--------------------------------------------------------------------------------");
  console.log("TOTAL ESTIMATED OPEX      | Frankfurt + Storage + AI| ~$325.00 / mo  | ~€300.00 / mo");
  console.log("--------------------------------------------------------------------------------\n");

  const entries = StateStore.getInstance().getAccountingEntries();
  console.log("TRANSACTION LEDGER HISTORY:");
  console.log("DATE       | CATEGORY        | DESCRIPTION                             | AMOUNT (USD) | AMOUNT (EUR)");
  console.log("--------------------------------------------------------------------------------");
  entries.forEach(e => {
    const sign = e.type === 'INCOME' ? '+' : '';
    const dateStr = e.date.padEnd(10);
    const catStr = e.category.padEnd(15);
    const descStr = e.description.padEnd(39);
    const usdStr = `${sign}$${e.amountUsd.toFixed(2)}`.padEnd(12);
    const eurStr = `${sign}€${e.amountEur.toFixed(2)}`;
    console.log(`${dateStr} | ${catStr} | ${descStr} | ${usdStr} | ${eurStr}`);
  });
  console.log("--------------------------------------------------------------------------------\n");
}

function showKanban(): void {
  console.log("\n>>> [7] INTERACTIVE KANBAN TASK MANAGEMENT BOARD");
  console.log("================================================================================");
  const tasks = StateStore.getInstance().getKanbanTasks();
  const backlog = tasks.filter(t => t.column === 'backlog');
  const inProgress = tasks.filter(t => t.column === 'in-progress');
  const review = tasks.filter(t => t.column === 'review');
  const done = tasks.filter(t => t.column === 'done');

  console.log(`BACKLOG [${backlog.length}]:`);
  backlog.forEach(t => console.log(`   • [${t.id}] ${t.title} (${t.assignee})`));

  console.log(`\nIN PROGRESS [${inProgress.length}]:`);
  inProgress.forEach(t => console.log(`   • [${t.id}] ${t.title} (${t.assignee})`));

  console.log(`\nREVIEW [${review.length}]:`);
  review.forEach(t => console.log(`   • [${t.id}] ${t.title} (${t.assignee})`));

  console.log(`\nDONE [${done.length}]:`);
  done.forEach(t => console.log(`   • [${t.id}] ${t.title} (${t.assignee})`));
  console.log("================================================================================");
}

function runTests(): number {
  console.log("================================================================================");
  console.log("RUNNING TS AUTOMATED TEST SUITE FOR CI VERIFICATION");
  console.log("================================================================================");

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, msg: string) {
    if (condition) {
      console.log(`[PASS] ${msg}`);
      passed++;
    } else {
      console.error(`[FAIL] ${msg}`);
      failed++;
    }
  }

  // Test 1: StateStore Accounting Entries
  const entries = StateStore.getInstance().getAccountingEntries();
  assert(entries.length >= 3, "StateStore contains default accounting entries");
  assert(entries.every(e => !("RUB" in e) && !("₽" in e)), "Strict Currency compliance (No RUB/₽)");

  // Test 2: Add Accounting Entry
  const newAcc = StateStore.getInstance().addAccountingEntry({
    date: '2026-09-02',
    category: 'Testing',
    description: 'Automated CI Test Entry',
    amountUsd: 100.00,
    amountEur: 92.30,
    type: 'EXPENSE'
  });
  assert(newAcc.id.startsWith('acc-'), "Accounting entry creation succeeded");

  // Test 3: Kanban Tasks
  const tasks = StateStore.getInstance().getKanbanTasks();
  assert(tasks.length >= 7, "Kanban tasks initialized correctly");

  // Test 4: Move Kanban Task
  StateStore.getInstance().moveKanbanTask('TASK-104', 'in-progress');
  const updatedTask = StateStore.getInstance().getKanbanTasks().find(t => t.id === 'TASK-104');
  assert(updatedTask?.column === 'in-progress', "Kanban task movement succeeded");

  // Test 5: MdUiParser Engine
  const sampleMd = `# TEST UI\n## TAB 1\n### SUBSECTION\n- Item 1\n| A | B |\n|---|---|\n| 1 | 2 |\n[Click](action:testFunc)`;
  const parsed = MdUiParser.getInstance().parse(sampleMd);
  assert(parsed.title === 'TEST UI', "MdUiParser parses markdown title");
  assert(parsed.tabs.length === 1, "MdUiParser parses tabs");
  assert(parsed.rawHtml.includes('<table border="1"'), "MdUiParser renders pure HTML grid table");

  // Test 6: MarkdownLiveEngine Reactive Engine
  const liveEngine = MarkdownLiveEngine.getInstance();
  const sampleLive = `# TEST LIVE\n- CPU: [metric:frankfurt_cpu]\n[progress:50 100 "CPU Bar"]`;
  const processed = liveEngine.processLiveMarkdown(sampleLive);
  assert(processed.includes('3.2%'), "MarkdownLiveEngine substitutes metric tokens");
  assert(processed.includes('[██████████░░░░░░░░░░] 50%'), "MarkdownLiveEngine generates ASCII progress bars");

  console.log("================================================================================");
  console.log(`TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log("================================================================================");

  return failed === 0 ? 0 : 1;
}

function showMdUi(): void {
  const sampleMd = `# EVABOT ONLINE // MD-UI ENGINE DEMO\n## [1] TELEMETRY\n| NODE | LOCATION | STATUS |\n|---|---|---|\n| agent-vm | Frankfurt | ONLINE |\n| micro-vm | Iowa | ALWAYS FREE |`;
  const result = MdUiParser.getInstance().parse(sampleMd);
  console.log("\n>>> [MD-UI] PARSED MARKDOWN INTERFACE OUTPUT:");
  console.log("================================================================================");
  console.log(result.rawHtml);
  console.log("================================================================================");
}

function showLive(): void {
  const liveEngine = MarkdownLiveEngine.getInstance();
  const sample = `# EVABOT ONLINE // MARKDOWN-LIVE TERMINAL STREAM\n- CPU LOAD: [metric:frankfurt_cpu]\n- RAM LOAD: [metric:frankfurt_ram]\n[progress:18.1 100 "RAM Usage"]`;
  const processed = liveEngine.processLiveMarkdown(sample);
  console.log("\n>>> [MARKDOWN-LIVE] REACTIVE TERMINAL METRICS STREAM:");
  console.log("================================================================================");
  console.log(processed);
  console.log("================================================================================");
}

function main(): void {
  const args = process.argv.slice(2);

  if (args.includes('--test')) {
    process.exit(runTests());
  }

  if (args.includes('--live')) {
    showLive();
    process.exit(0);
  }

  if (args.includes('--mdui')) {
    showMdUi();
    process.exit(0);
  }

  if (args.includes('--telemetry')) {
    showTelemetry();
    process.exit(0);
  }

  if (args.includes('--accounting') || args.includes('--costs')) {
    showAccounting();
    process.exit(0);
  }

  if (args.includes('--kanban')) {
    showKanban();
    process.exit(0);
  }

  if (args.includes('--all')) {
    console.log(getBanner());
    showTelemetry();
    showAccounting();
    showKanban();
    process.exit(0);
  }

  // Default output
  console.log(getBanner());
  showTelemetry();
  showAccounting();
  showKanban();
}

main();
