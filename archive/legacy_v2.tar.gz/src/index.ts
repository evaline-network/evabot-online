import { PluginManager } from './plugins/PluginManager.js';
import { ChatVoicePlugin } from './modules/ChatVoicePlugin.js';
import { TelemetryPlugin } from './modules/TelemetryPlugin.js';
import { AccountingPlugin } from './modules/AccountingPlugin.js';
import { ModelHubPlugin } from './modules/ModelHubPlugin.js';
import { MessengersPlugin } from './modules/MessengersPlugin.js';
import { AuditLogPlugin } from './modules/AuditLogPlugin.js';
import { KanbanPlugin } from './modules/KanbanPlugin.js';
import { MdUiPlugin } from './modules/MdUiPlugin.js';
import { MarkdownLivePlugin } from './modules/MarkdownLivePlugin.js';
import { Language, IKanbanTask } from './core/Types.js';
import { StateStore } from './core/StateStore.js';
import { VoiceEngine } from './core/VoiceEngine.js';

class EvaBotApp {
  private pluginManager: PluginManager;

  constructor() {
    this.pluginManager = new PluginManager();
  }

  public init(): void {
    // Register all plugins
    this.pluginManager.registerPlugin(new ChatVoicePlugin());
    this.pluginManager.registerPlugin(new TelemetryPlugin());
    this.pluginManager.registerPlugin(new AccountingPlugin());
    this.pluginManager.registerPlugin(new ModelHubPlugin());
    this.pluginManager.registerPlugin(new MessengersPlugin());
    this.pluginManager.registerPlugin(new AuditLogPlugin());
    this.pluginManager.registerPlugin(new KanbanPlugin());
    this.pluginManager.registerPlugin(new MdUiPlugin());
    this.pluginManager.registerPlugin(new MarkdownLivePlugin());

    // Initial render
    this.pluginManager.renderAll();
  }

  public setLanguage(lang: Language): void {
    this.pluginManager.setLanguage(lang);
  }

  public setScreen(screenId: string): void {
    this.pluginManager.setScreen(screenId);
  }

  public toggleAllAccordions(expand: boolean): void {
    this.pluginManager.toggleAllAccordions(expand);
  }

  public togglePlugin(pluginId: string): void {
    this.pluginManager.togglePluginState(pluginId);
  }

  public submitPrompt(e: Event): void {
    e.preventDefault();
    const input = document.getElementById('term-input') as HTMLInputElement;
    const stream = document.getElementById('chat-stream');
    if (!input || !stream || !input.value.trim()) return;

    const q = input.value.trim();
    stream.innerText += `\n\n[USER]: ${q}`;

    const lang = this.pluginManager.getLanguage();
    let reply = `[EVABOT]: Received query: "${q}". Processing via Google Gemini Core (Google AI Pro 2M Context Window)... All physical/virtual metrics optimal ($0.00 micro-node, c3-std-8 active).`;
    if (lang === 'uk') {
      reply = `[EVABOT]: Отримано запит: "${q}". Обробка через Google Gemini Core... Усі метрики в нормі ($0.00 мікросервер, c3-std-8 активний).`;
    } else if (lang === 'ru') {
      reply = `[EVABOT]: Получен запрос: "${q}". Обработка через Google Gemini Core... Все метрики в норме ($0.00 микросервер, c3-std-8 активен).`;
    }

    setTimeout(() => {
      stream.innerText += `\n${reply}`;
      input.value = '';
    }, 300);
  }

  public addAccountingEntry(e: Event): void {
    e.preventDefault();
    const date = (document.getElementById('acc-date') as HTMLInputElement).value;
    const category = (document.getElementById('acc-category') as HTMLSelectElement).value;
    const description = (document.getElementById('acc-desc') as HTMLInputElement).value;
    const amountVal = parseFloat((document.getElementById('acc-amount') as HTMLInputElement).value);
    const type = (document.getElementById('acc-type') as HTMLSelectElement).value as 'INCOME' | 'EXPENSE';

    if (!date || !description || isNaN(amountVal)) return;

    StateStore.getInstance().addAccountingEntry({
      date,
      category,
      description,
      amountUsd: amountVal,
      amountEur: parseFloat((amountVal * 0.923).toFixed(2)),
      type
    });

    // Re-render Accounting Plugin
    this.pluginManager.renderAll();
  }

  public moveKanbanTask(taskId: string, targetCol: IKanbanTask['column']): void {
    StateStore.getInstance().moveKanbanTask(taskId, targetCol);
    this.pluginManager.renderAll();
  }

  public addKanbanTask(e: Event): void {
    e.preventDefault();
    const title = (document.getElementById('task-title') as HTMLInputElement).value.trim();
    const priority = (document.getElementById('task-priority') as HTMLSelectElement).value as any;
    const tagsInput = (document.getElementById('task-tags') as HTMLInputElement).value.trim();
    const assignee = (document.getElementById('task-assignee') as HTMLInputElement).value.trim() || 'Unassigned';

    if (!title) return;

    const tags = tagsInput ? tagsInput.split(' ') : ['#General'];

    StateStore.getInstance().addKanbanTask({
      title,
      priority,
      tags,
      assignee,
      description: title
    });

    this.pluginManager.renderAll();
  }

  public speakReport(): void {
    const lang = this.pluginManager.getLanguage();
    const text = lang === 'en'
      ? "Hello! This is Eva. Delivering the official launch report for our system. Tonight, exactly at zero zero zero one, we activated our cluster on Google Cloud."
      : (lang === 'uk'
        ? "Вітаю! На зв'язку Єва. Передаю офіційний звіт про запуск нашої системи. Сьогодні вночі, рівно о нуль-нуль нуль-один, ми активували наш кластер у Гугл Клауд."
        : "Здравствуйте! На связи Ева. Передаю официальный отчет о запуске нашей системы. Сегодня ночью, ровно в ноль-ноль ноль-один, мы активировали наш кластер в Гугл Клауд.");

    const ind = document.getElementById('voice-indicator');
    if (ind) ind.innerText = 'SPEAKING...';

    VoiceEngine.getInstance().speak(text, lang, () => {
      if (ind) ind.innerText = 'VOICE READY';
    });
  }

  public stopVoice(): void {
    VoiceEngine.getInstance().stop();
    const ind = document.getElementById('voice-indicator');
    if (ind) ind.innerText = 'VOICE READY';
  }

  public toggleVoiceInput(): void {
    alert('Voice input active. Speak into microphone...');
  }
}

// Global bootstrap
declare global {
  interface Window {
    evaApp: EvaBotApp;
  }
}

const app = new EvaBotApp();
if (typeof window !== 'undefined') {
  window.evaApp = app;
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => app.init());
  } else {
    app.init();
  }
}
