# EvaBot & Evaline Online — Повна Документація Проєкту

> **Версія системи:** v2.7.0 / Реліз v0.0.1  
> **Інфраструктура:** Google Cloud Platform (Франкфурт `c3-standard-8` & Айова `e2-micro`)  
> **Промисловий домен:** [https://evabot.online](https://evabot.online)  
> **Репозиторій GitHub:** [`evabot-online/evaline-online`](https://github.com/evabot-online/evaline-online)  

---

## 1. Архітектурний Огляд та Концепція

**EvaBot & Evaline Online** — це модульна корпоративна екосистема штучного інтелекту та автономний центр керування на платформі Google Cloud Platform (GCP). Архітектура суворо відокремлює публічний вебтрафік від важких обчислювальних ШІ-навантажень.

```mermaid
flowchart TD
    User([Користувачі та Вебклієнти]) -->|HTTPS / TLS 1.3 / HTTP/3| Caddy[Вебсервер Caddy 2.11.4]
    
    subgraph Edge_Node ["Прикордонний вузол: evaline-micro-vm (Айова, us-central1-a) — Always Free ($0.00/міс)"]
        Caddy --> WebRoot["/var/www/evabot.online (Інтерфейс)"]
        Caddy --> ReverseProxy[Зворотний проксі / Захисний щит]
    end

    ReverseProxy -->|Мережа Tailscale WireGuard 100.125.200.49| AgentVM
    
    subgraph Core_Node ["Головний обчислювальний вузол: evabot-agent-vm (Франкфурт, europe-west3-a)"]
        AgentVM[c3-standard-8: 8 vCPU Sapphire Rapids, 32GB RAM]
        AgentVM --> Qdrant[Векторна база даних Qdrant]
        AgentVM --> Messengers[Шлюзи месенджерів: Telegram, WhatsApp, Viber, FB]
        AgentVM --> GeminiAPI[API Google Gemini Core / Google AI Pro]
    end
```

### Специфікація Вузлів Інфраструктури

| Параметр | Прикордонний Sentinel-вузол (`evaline-micro-vm`) | Головний Обчислювальний Вузол (`evabot-agent-vm`) |
| :--- | :--- | :--- |
| **Зона GCP** | `us-central1-a` (Каунсіл-Блаффс, Айова, США) | `europe-west3-a` (Франкфурт, Німеччина) |
| **Конфігурація** | `e2-micro` (2 vCPU burst, 1 ГБ RAM) | `c3-standard-8` (8 vCPU Sapphire Rapids, 32 ГБ RAM) |
| **Операційна система** | Debian 13 (Trixie 13.6) | Debian 12 (Bookworm) |
| **Основна роль** | Інгрес, TLS 1.3/HTTP3 Caddy, Фронтенд | Ядро Gemini ШІ, Qdrant DB, Бот-шлюзи |
| **Публічний IP** | `136.114.26.252` | `34.179.253.183` |
| **Внутрішній IP Mesh**| `10.128.0.2` (VPC) / Tailscale Mesh | `10.156.0.2` (VPC) / Tailscale Mesh |
| **Вартість на місяць** | **$0.00 / місяць** (€0.00 / місяць) | **~$290.00 – $320.00 / місяць** (€268.00 – €296.00 / місяць) |

---

## 2. Інтерактивний Вебінтерфейс (7 Екранних Модулів)

Головний вебзастосунок (`index.html`) складається з семи функціональних екранів:

1. **Екран 1: Чат Gemini Core & Живий Голосовий Асистент**
   - Інтерактивний діалоговий інтерфейс на базі моделей Google Gemini (підписка Google AI Pro з вікном контексту 2,000,000 токенів).
   - Розпізнавання мовлення та синтез нейронного жіночого голосу з природною артикуляцією.
2. **Екран 2: Телеметрія Серверів та Кластера**
   - Моніторинг завантаження vCPU, оперативної пам'яті RAM, NVMe-дисків та мережевого трафіку вузлів у Франкфурті та Айові в реальному часі.
3. **Екран 3: Витрати та бухгалтерія (Expenses & Accounting)**
   - Фінансова аналітика витрат GCP суворо у **USD ($)** та **EUR (€)**.
   - Бухгалтерський журнал доходів і витрат (P&L Ledger), категорії витрат та динамічне введення транзакцій.
4. **Екран 4: Каталог Моделей ШІ (AI Model Hub)**
   - Рейтинг Топ-10 Флагманських Моделей (Gemini 2.0 Pro, Claude 3.5 Sonnet, GPT-4o, DeepSeek-R1) та Топ-10 Безкоштовних/Open-Source Моделей (Llama 3.3 70B, Mistral Small 3, Qwen 2.5 72B).
5. **Екран 5: Модулі та Шлюзи Месенджерів**
   - Статус підключення вебхуків та інтеграцій Telegram, WhatsApp, Viber та Facebook Messenger.
6. **Екран 6: Хронологічний Аудит-Лог та Голосовий Звіт**
   - Журнал подій системи: позначки розгортання, автооновлення SSL-сертифікатів Let's Encrypt та системні логи.
7. **Екран 7: Інтерактивна Канбан Дошка (Kanban Board)**
   - Керування завданнями проєкту з 4 колонками: **Беклог**, **В роботі**, **На перевірці** та **Завершено**.
   - Додавання карток завдань, пріоритети (`HIGH`, `MED`, `LOW`), теги (`#GCP`, `#AI`, `#DevOps`) та переміщення завдань.

---

## 3. Автономний Термінальний CLI-Клієнт (`evabot-cli.py`)

Інтерфейс CLI надає текстовий пульт керування без зовнішніх залежностей.

### Команди CLI

```bash
# Запуск інтерактивного термінального UI
python3 evabot-cli.py

# Автоматичний неінтерактивний самотест
python3 evabot-cli.py --test

# Довідка за аргументами
python3 evabot-cli.py --help
```

---

## 4. Автоматична Тристороння Синхронізація Git та GCP

Синхронізація між локальним середовищем, GitHub та сервером GCP виконується скриптом [`deploy-sync.sh`](file:///home/fedor/Desktop/evabot-online/deploy-sync.sh).

```
[Локальний ПК: /home/fedor/Desktop/evabot-online]
       │
       ▼ (git push)
[GitHub Репозиторій: evabot-online/evaline-online (main)]
       │
       ▼ (gcloud ssh & git pull)
[Мікросервер GCP: /home/fedor/Desktop/evabot-online]
       │
       ▼ (sudo cp / rsync)
[Промисловий Вебкаталог: /var/www/evabot.online]
```

### Запуск Синхронізації

```bash
./deploy-sync.sh "feat: оновлення документації та екранів"
```

---

## 5. Фінансова Модель OpEx та Оптимізація Витрат

| Компонент Витрат | Вартість на місяць (USD) | Вартість на місяць (EUR) | Тарифна Політика |
| :--- | :--- | :--- | :--- |
| `evaline-micro-vm` (e2-micro) | **$0.00** | **€0.00** | GCP Always Free Tier (Айова, 744 години/міс) |
| Системний диск (20 GB HDD) | **$0.00** | **€0.00** | GCP Always Free (квота до 30 GB) |
| Вихідний трафік (< 1 GB) | **$0.00** | **€0.00** | Безкоштовна квота GCP |
| `evabot-agent-vm` (c3-standard-8) | **~$290.00 – $320.00** | **~$268.00 – €296.00** | On-Demand інстанс (Франкфурт) |
| Диск NVMe (50 GB data) | **~$5.00** | **~$4.60** | Zonal SSD storage |
| Підписка Google AI Pro | **$20.00** | **€18.50** | Фіксована підписка (Gemini 2M Context) |
| **Підсумковий операційний OpEx** | **~$315.00 – $345.00** | **~$291.00 – €319.00** | Суворо USD / EUR розрахунки |

> [!TIP]
> Використання `evaline-micro-vm` як проксі замість хмарного балансувальника GCP Application Load Balancer заощаджує від **$28.50 до $35.00 на місяць (€26.40 – €32.40 / місяць)**.
