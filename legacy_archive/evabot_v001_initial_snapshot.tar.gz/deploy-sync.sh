#!/usr/bin/env bash
# ==============================================================================
# EVABOT ONLINE - THREE-WAY AUTOMATED SYNC & DEPLOYMENT SCRIPT
# Local (/home/fedor/Desktop/evabot-online) <-> GitHub <-> GCP Microserver
# ==============================================================================
set -e

MSG="${1:-"feat: automated sync and update from local desktop"}"

echo "================================================================================"
echo "0. Building TypeScript bundle and running tests..."
echo "================================================================================"
npm run build
npm test

echo ""
echo "================================================================================"
echo "1. Pushing local changes to GitHub (evabot-online/evaline-online)..."
echo "================================================================================"
git add .
git commit -m "$MSG" || echo "No changes to commit."
git push origin main

echo ""
echo "================================================================================"
echo "2. Synchronizing GCP Microserver (evaline-micro-vm / Iowa e2-micro)..."
echo "================================================================================"
gcloud compute ssh evaline-micro-vm --zone=us-central1-a --quiet --command="
  cd /home/fedor/Desktop/evabot-online && \
  git pull origin main && \
  sudo cp -rf /home/fedor/Desktop/evabot-online/* /var/www/evabot.online/ && \
  sudo chown -R www-data:www-data /var/www/evabot.online && \
  echo '🟢 Microserver /var/www/evabot.online deployment complete.'
"

echo ""
echo "================================================================================"
echo "✅ SYNC SUCCESSFUL! All 3 locations are synchronized:"
echo "   - Local:      /home/fedor/Desktop/evabot-online"
echo "   - GitHub:     https://github.com/evabot-online/evaline-online"
echo "   - Microserver: /home/fedor/Desktop/evabot-online & https://evabot.online"
echo "================================================================================"
