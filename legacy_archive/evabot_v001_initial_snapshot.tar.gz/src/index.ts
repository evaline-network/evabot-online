import { LiveMarkdownEngine, ViewMode } from './core/LiveMarkdownEngine.js';
import { Language } from './core/Types.js';

class EvaBotLiveApp {
  private engine: LiveMarkdownEngine;
  private timer: any = null;
  private angleY: number = 0;

  // 3D Head Wireframe Mesh Coordinates (x, y, z)
  private headVertices: Array<[number, number, number]> = [
    // Forehead & Crown
    [0, 90, 0], [-30, 80, -20], [30, 80, -20], [-60, 60, -40], [60, 60, -40],
    // Eyes & Brow Line
    [-40, 30, 40], [-15, 30, 50], [15, 30, 50], [40, 30, 40],
    // Nose Bridge & Tip
    [0, 30, 55], [0, 0, 70], [-15, -10, 45], [15, -10, 45],
    // Cheekbones
    [-70, 10, -10], [70, 10, -10], [-60, -20, 20], [60, -20, 20],
    // Mouth & Lips
    [-25, -30, 45], [0, -28, 55], [25, -30, 45], [0, -35, 52],
    // Jaw & Chin
    [-45, -50, 10], [45, -50, 10], [-20, -75, 35], [0, -80, 40], [20, -75, 35]
  ];

  // Polygon Edges (indices connecting 3D vertices)
  private headEdges: Array<[number, number]> = [
    [0, 1], [0, 2], [1, 3], [2, 4], [3, 13], [4, 14],
    [1, 5], [2, 8], [5, 6], [6, 7], [7, 8],
    [6, 9], [7, 9], [9, 10], [10, 11], [10, 12],
    [5, 13], [8, 14], [13, 15], [14, 16],
    [11, 17], [10, 18], [12, 19], [17, 18], [18, 19], [17, 20], [19, 20],
    [15, 21], [16, 22], [21, 23], [22, 25], [23, 24], [25, 24]
  ];

  private templates: Record<Language, string> = {
    en: `# ⚡ EVABOT ONLINE v0.0.1 // ULTRA HYPER-UI SPECIFICATION

## 👤 [SCREEN 1: 3D CYBER MESH FACE & LLM PROMPT CHAT CONSOLE]
### 📍 BLOCK 1.1: INTERACTIVE 3D WIREFRAME MESH FACE BUTTON
[block:3d_cyber_face]

### 📍 BLOCK 1.2: LLM PROMPT COMMAND LINE INPUT BAR
**TYPE PROMPT FOR EVABOT (v0.0.1):** [input:term-input "type prompt for LLM agent..."] [SEND PROMPT](action:submitPrompt)

### 📍 BLOCK 1.3: LIVE INTERACTIVE GEMINI CORE CHAT STREAM
[block:live_chat]

---

## 🖥️ [SCREEN 2: REAL-TIME CLOUD TELEMETRY & CLUSTER NODES]
### 📍 BLOCK 2.1: PRIMARY COMPUTE NODE (FRANKFURT c3-standard-8)
[source:gcloud "34.179.253.183 (VPC 10.156.0.2)"]
- **LOCATION:** Frankfurt europe-west3-a | **SYSTEM UPTIME:** \`[metric:uptime]\`
- **LIVE CPU LOAD:** **[metric:frankfurt_cpu]**
[progress:frankfurt_cpu]
- **LIVE RAM USAGE:** **[metric:frankfurt_ram]**
[progress:frankfurt_ram]

| COMPONENT | SPECIFICATION | REAL-TIME STATUS | LIVE METRIC |
| CPU Cores | 8 vCPU Intel Sapphire Rapids | [ONLINE] STREAMING | [metric:frankfurt_cpu] |
| RAM Load | 32 GB DDR5 RAM | [ONLINE] STREAMING | [metric:frankfurt_ram] |

### 📍 BLOCK 2.2: EDGE MICRO NODE (IOWA e2-micro ALWAYS FREE)
[source:gcloud "136.114.26.252 (VPC 10.128.0.2)"]
- **LOCATION:** Iowa us-central1-a | **PRICING TIER:** GCP Always Free ($0.00 / mo)
- **LIVE CPU LOAD:** **[metric:iowa_cpu]**
[progress:iowa_cpu]
- **LIVE RAM USAGE:** **[metric:iowa_ram]**
[progress:iowa_ram]

---

## 💰 [SCREEN 3: EXPENSES & FINANCIAL ACCOUNTING LEDGER]
### 📍 BLOCK 3.1: OPEX OVERVIEW & BALANCES (USD $ / EUR € ONLY)
- **ESTIMATED MONTHLY OPEX:** **[metric:opex_usd]** (**[metric:opex_eur]**)
- **ALWAYS FREE SAVINGS:** $0.00 / mo (€0.00 / mo)

[block:live_accounting]

---

## 📊 [SCREEN 4: INTERACTIVE KANBAN TASK BOARD]
### 📍 BLOCK 4.1: CLUSTER WORKFLOW GRID

[block:live_kanban]
`,
    uk: `# ⚡ EVABOT ONLINE v0.0.1 // ULTRA HYPER-UI СПЕЦИФІКАЦІЯ

## 👤 [ЕКРАН 1: 3D КІБЕР-ОБЛИЧЧЯ ТА КОНСОЛЬ ПРОМПТІВ LLM]
### 📍 БЛОК 1.1: ІНТЕРАКТИВНА 3D КНОПКА-ОБЛИЧЧЯ З СІТКОЮ ПОЛІГОНІВ
[block:3d_cyber_face]

### 📍 БЛОК 1.2: СТРІЧКА ВВЕДЕННЯ ПРОМПТУ ДЛЯ LLM
**ВВЕДІТЬ ЗАПИТ ДЛЯ EVABOT (v0.0.1):** [input:term-input "введіть запит для LLM агента..."] [НАДІСЛАТИ](action:submitPrompt)

### 📍 БЛОК 1.3: ЖИВИЙ ЧАТ GEMINI CORE
[block:live_chat]

---

## 🖥️ [ЕКРАН 2: ТЕЛЕМЕТРІЯ СЕРВЕРІВ У РЕАЛЬНОМУ ЧАСІ]
### 📍 БЛОК 2.1: ОСНОВНИЙ ВУЗОЛ (ФРАНКФУРТ c3-standard-8)
[source:gcloud "34.179.253.183 (VPC 10.156.0.2)"]
- **РОЗТАШУВАННЯ:** Франкфурт europe-west3-a | **ЧАС РОБОТИ:** \`[metric:uptime]\`
- **ЖИВЕ НАВАНТАЖЕННЯ CPU:** **[metric:frankfurt_cpu]**
[progress:frankfurt_cpu]
- **ЖИВЕ ВИКОРИСТАННЯ RAM:** **[metric:frankfurt_ram]**
[progress:frankfurt_ram]

---

## 💰 [ЕКРАН 3: ВИТРАТИ ТА БУХГАЛТЕРІЯ]
### 📍 БЛОК 3.1: ОГЛЯД OPEX ТА БАЛАНСИ (ЛИШЕ USD $ / EUR €)
- **ОЦІНКА МІСЯЧНОГО OPEX:** **[metric:opex_usd]** (**[metric:opex_eur]**)

[block:live_accounting]

---

## 📊 [ЕКРАН 4: ІНТЕРАКТИВНА КАНБАН-ДОШКА ЗАДАЧ]
### 📍 БЛОК 4.1: СІТКА РОБОЧОГО ПРОЦЕСУ

[block:live_kanban]
`,
    ru: `# ⚡ EVABOT ONLINE v0.0.1 // ULTRA HYPER-UI СПЕЦИФИКАЦИЯ

## 👤 [ЭКРАН 1: 3D КИБЕР-ЛИЦО И КОНСОЛЬ ПРОМПТОВ LLM]
### 📍 БЛОК 1.1: ИНТЕРАКТИВНАЯ 3D КНОПКА-ЛИЦО С СЕТКОЙ ПОЛИГОНОВ
[block:3d_cyber_face]

### 📍 БЛОК 1.2: СТРОКА ВВОДА ПРОМПТА ДЛЯ LLM
**ВВЕДИТЕ ЗАПРОС ДЛЯ EVABOT (v0.0.1):** [input:term-input "введите запрос для LLM агента..."] [ОТПРАВИТЬ](action:submitPrompt)

### 📍 БЛОК 1.3: ЖИВОЙ ЧАТ GEMINI CORE
[block:live_chat]

---

## 🖥️ [ЭКРАН 2: ТЕЛЕМЕТРИЯ СЕРВЕРОВ В РЕАЛЬНОМ ВРЕМЕНИ]
### 📍 БЛОК 2.1: ОСНОВНОЙ УЗЕЛ (ФРАНКФУРТ c3-standard-8)
[source:gcloud "34.179.253.183 (VPC 10.156.0.2)"]
- **РАСПОЛОЖЕНИЕ:** Франкфурт europe-west3-a | **ВРЕМЯ РАБОТЫ:** \`[metric:uptime]\`
- **ЖИВАЯ НАГРУЗКА CPU:** **[metric:frankfurt_cpu]**
[progress:frankfurt_cpu]
- **ЖИВОЕ ИСПОЛЬЗОВАНИЕ RAM:** **[metric:frankfurt_ram]**
[progress:frankfurt_ram]

---

## 💰 [ЭКРАН 3: РАСХОДЫ И БУХГАЛТЕРИЯ]
### 📍 БЛОК 3.1: ОБЗОР OPEX И БАЛАНСЫ (СТРОГО USD $ / EUR €)
- **ОЦЕНКА МЕСЯЧНОГО OPEX:** **[metric:opex_usd]** (**[metric:opex_eur]**)

[block:live_accounting]

---

## 📊 [ЭКРАН 4: ИНТЕРАКТИВНАЯ КАНБАН-ДОСКА ЗАДАЧ]
### 📍 БЛОК 4.1: СЕТКА РАБОЧЕГО ПРОЦЕССА

[block:live_kanban]
`
  };

  constructor() {
    this.engine = LiveMarkdownEngine.getInstance();
    this.engine.setViewMode('BEAUTIFUL_HYPER_UI');
  }

  public init(): void {
    this.renderHeader();
    this.render();
    if (!this.timer) {
      this.timer = setInterval(() => {
        this.engine.tick();
        this.render();
      }, 1000);
    }
  }

  public setLanguage(lang: Language): void {
    this.engine.setLanguage(lang);
    this.renderHeader();
    this.render();
  }

  public setViewMode(mode: ViewMode): void {
    this.engine.setViewMode(mode);
    this.renderHeader();
    this.render();
  }

  public toggleAllAccordions(expand: boolean): void {
    document.querySelectorAll('details').forEach(d => {
      d.open = expand;
    });
  }

  public toggleVoiceInput(e?: Event): void {
    if (e) e.preventDefault();
    const active = this.engine.toggleVoice();
    if (active) {
      alert("🎙️ GEMINI LIVE VOICE ACTIVATED (v0.0.1 Starter Demo Mode)!\nSpeak into your microphone. Listening...");
    } else {
      alert("⏹ GEMINI LIVE VOICE DEACTIVATED.");
    }
    this.render();
  }

  public submitPrompt(e: Event): void {
    e.preventDefault();
    const input = document.getElementById('term-input') as HTMLInputElement;
    if (!input || !input.value.trim()) return;

    const query = input.value.trim();
    this.engine.addChatMessage(query);
    input.value = '';
    this.render();
  }

  public renderHeader(): void {
    const header = document.getElementById('app-header');
    if (!header) return;

    const lang = this.engine.getLanguage();
    const mode = this.engine.getViewMode();

    const m1Class = mode === 'BEAUTIFUL_HYPER_UI' ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold shadow-lg shadow-cyan-500/50' : 'bg-slate-900 text-slate-300 border border-slate-700 hover:border-cyan-500/50';
    const m2Class = mode === 'PURE_NO_CSS_TUI' ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold shadow-lg shadow-cyan-500/50' : 'bg-slate-900 text-slate-300 border border-slate-700 hover:border-cyan-500/50';
    const m3Class = mode === 'RAW_MARKDOWN' ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold shadow-lg shadow-cyan-500/50' : 'bg-slate-900 text-slate-300 border border-slate-700 hover:border-cyan-500/50';

    header.innerHTML = `
    <div class="bg-slate-950/90 backdrop-blur-xl border border-cyan-500/40 rounded-2xl p-4 sm:p-6 shadow-2xl shadow-cyan-950/40 max-w-7xl mx-auto">
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div class="flex items-center gap-2">
            <span class="inline-block w-3 h-3 rounded-full bg-cyan-400 animate-ping"></span>
            <h1 class="font-orbitron text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-200 to-purple-400 tracking-wider">[EVABOT] AUTONOMOUS AGENT COMMAND CENTER</h1>
          </div>
          <p class="font-mono text-xs text-slate-400 mt-1">
            <span class="text-cyan-400">VERSION:</span> STARTER DEMO MODE v0.0.1 │ 
            <span class="text-purple-400">TELEMETRY:</span> 1000ms REAL-TIME TICK │ 
            <span class="text-emerald-400">INFRA:</span> GCP (FRANKFURT + IOWA)
          </p>
        </div>

        <!-- MODE SELECTOR BUTTONS -->
        <div class="flex items-center gap-2 flex-wrap font-orbitron text-xs">
          <button onclick="window.evaApp.setViewMode('BEAUTIFUL_HYPER_UI')" class="px-4 py-2 rounded-xl uppercase tracking-wider transition-all transform hover:scale-105 active:scale-95 ${m1Class}">✨ MODE 1: HYPER UI</button>
          <button onclick="window.evaApp.setViewMode('PURE_NO_CSS_TUI')" class="px-4 py-2 rounded-xl uppercase tracking-wider transition-all transform hover:scale-105 active:scale-95 ${m2Class}">📺 MODE 2: HTML TUI</button>
          <button onclick="window.evaApp.setViewMode('RAW_MARKDOWN')" class="px-4 py-2 rounded-xl uppercase tracking-wider transition-all transform hover:scale-105 active:scale-95 ${m3Class}">📄 MODE 3: MARKDOWN</button>
        </div>
      </div>

      <!-- LANGUAGE SELECTOR -->
      <div class="flex items-center justify-between pt-3 font-mono text-xs">
        <div class="flex items-center gap-2">
          <span class="text-slate-500">LANGUAGES:</span>
          <button onclick="window.evaApp.setLanguage('en')" class="px-3 py-1 rounded-lg ${lang === 'en' ? 'bg-cyan-950 border border-cyan-500/50 text-cyan-300 font-bold' : 'text-slate-400 hover:text-cyan-300'}">[EN] ENGLISH</button>
          <button onclick="window.evaApp.setLanguage('uk')" class="px-3 py-1 rounded-lg ${lang === 'uk' ? 'bg-cyan-950 border border-cyan-500/50 text-cyan-300 font-bold' : 'text-slate-400 hover:text-cyan-300'}">[UK] УКРАЇНСЬКА</button>
          <button onclick="window.evaApp.setLanguage('ru')" class="px-3 py-1 rounded-lg ${lang === 'ru' ? 'bg-cyan-950 border border-cyan-500/50 text-cyan-300 font-bold' : 'text-slate-400 hover:text-cyan-300'}">[RU] РУССКИЙ</button>
        </div>
        <div class="text-slate-500 hidden sm:block">
          STATUS: <span class="text-emerald-400 font-bold">[● CLUSTER ONLINE]</span>
        </div>
      </div>
    </div>
    `;
  }

  public render(): void {
    const root = document.getElementById('live-app-root');
    if (!root) return;

    const lang = this.engine.getLanguage();
    const mode = this.engine.getViewMode();
    const template = this.templates[lang] || this.templates['en'];
    const liveMarkdown = this.engine.processLiveMarkdown(template);
    const htmlOutput = this.engine.renderByMode(liveMarkdown, mode);

    root.innerHTML = htmlOutput;
    this.drawCyberFaceCanvas();
  }

  private drawCyberFaceCanvas(): void {
    const canvas = document.getElementById('cyber-face-canvas') as HTMLCanvasElement;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    this.angleY += 0.03;
    const isVoice = this.engine.getTelemetry().voiceActive;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const scale = 1.2;

    const projected: Array<{ x: number; y: number; z: number }> = [];

    const cosY = Math.cos(this.angleY);
    const sinY = Math.sin(this.angleY);

    this.headVertices.forEach(([vx, vy, vz]) => {
      let rx = vx * cosY - vz * sinY;
      let ry = vy;
      let rz = vx * sinY + vz * cosY;

      if (isVoice) {
        rx += (Math.random() * 4 - 2);
        ry += (Math.random() * 4 - 2);
      }

      const fov = 300;
      const distance = 200;
      const factor = fov / (distance + rz);

      const px = cx + rx * factor * scale;
      const py = cy - ry * factor * scale;

      projected.push({ x: px, y: py, z: rz });
    });

    ctx.lineWidth = isVoice ? 1.8 : 1.2;
    ctx.strokeStyle = isVoice ? '#00ffcc' : '#00aaff';

    this.headEdges.forEach(([i1, i2]) => {
      const p1 = projected[i1];
      const p2 = projected[i2];
      if (p1 && p2) {
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
      }
    });

    projected.forEach((p) => {
      ctx.fillStyle = isVoice ? '#ff00ff' : '#00ffff';
      ctx.beginPath();
      const radius = isVoice ? 3.5 : 2.5;
      ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
      ctx.fill();
    });

    if (isVoice) {
      ctx.fillStyle = '#00ffcc';
      ctx.font = '12px monospace';
      ctx.fillText('LIVE VOICE MIC (v0.0.1): RECORDING...', 10, 20);
    }
  }
}

declare global {
  interface Window {
    evaApp: EvaBotLiveApp;
  }
}

const app = new EvaBotLiveApp();
if (typeof window !== 'undefined') {
  window.evaApp = app;
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => app.init());
  } else {
    app.init();
  }
}
